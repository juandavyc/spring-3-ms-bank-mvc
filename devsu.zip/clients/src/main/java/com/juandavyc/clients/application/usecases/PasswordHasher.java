package com.juandavyc.clients.application.usecases;

public interface PasswordHasher {

    String hash(String password);

}
