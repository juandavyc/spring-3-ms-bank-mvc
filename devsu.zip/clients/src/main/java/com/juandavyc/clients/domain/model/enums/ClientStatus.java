package com.juandavyc.clients.domain.model.enums;

public enum ClientStatus {
    ACTIVE, INACTIVE
}
