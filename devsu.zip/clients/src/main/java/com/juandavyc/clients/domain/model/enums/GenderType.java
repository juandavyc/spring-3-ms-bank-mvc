package com.juandavyc.clients.domain.model.enums;

public enum GenderType {
    MALE,
    FEMALE
}
