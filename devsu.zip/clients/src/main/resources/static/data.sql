INSERT INTO clients (id, password, status, full_name, gender, age, identification, address, phone_number)
VALUES ('e3f1c9c3-4b2a-4f8b-9b6d-1a2e3f4b5c6d', 'pass123', 'ACTIVE', 'Juan David', 'MALE', 21, '12345678',
        'Calle Falsa 123', '555-1111'),
       ('a1b2c3d4-5e6f-7a8b-9c0d-1e2f3a4b5c6d', 'pass124', 'ACTIVE', 'Maria Lopez', 'FEMALE', 30, '87654321',
        'Av. Siempre Viva 742', '555-2222'),
       ('f1e2d3c4-b5a6-7d8c-9e0f-1a2b3c4d5e6f', 'pass125', 'INACTIVE', 'Carlos Perez', 'MALE', 40, '11223344',
        'Calle Luna 12', '555-3333');