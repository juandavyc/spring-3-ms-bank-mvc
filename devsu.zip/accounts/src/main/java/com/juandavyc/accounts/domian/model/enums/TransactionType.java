package com.juandavyc.accounts.domian.model.enums;

public enum TransactionType {
    DEPOSIT, // agregar
    WITHDRAWAL // retiro
}
