package com.juandavyc.accounts.domian.model.enums;

public enum AccountStatus {
    ACTIVE,
    INACTIVE
}
