package com.juandavyc.accounts.domian.model.enums;

public enum AccountType {
    DEBIT,
    CREDIT
}
