package com.juandavyc.core.validation;

public class ValidationGroup {
    public interface OnCreate {}
    public interface OnUpdate {}
}
