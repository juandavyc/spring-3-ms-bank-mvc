package com.juandavyc.core.shared;

public enum ClientResponseCode implements ResponseCode{

    CREATED(201, "Cliente creado correctamente"),
    NOT_FOUND(404, "Cliente no encontrada"),
    SUCCESS(200, "Solicitud procesada exitosamente"),
    DELETED(200, "Cliente eliminado correctamente");


    private final int value;
    private final String message;

    ClientResponseCode(int value, String message) {
        this.value = value;
        this.message = message;
    }

    public int getValue() { return value; }
    public Enum<?> getStatus() { return this; } // o cambia según tu diseño
    public String getMessage() { return message; }
}
